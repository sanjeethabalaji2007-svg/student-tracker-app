const STORAGE_KEY = "studentFinanceApp.multiUser.v1";

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  });
}

const entryForm = document.getElementById("entry-form");
const typeInput = document.getElementById("type");
const amountInput = document.getElementById("amount");
const categoryInput = document.getElementById("category");
const noteInput = document.getElementById("note");
const dateInput = document.getElementById("date");

const totalIncomeEl = document.getElementById("total-income");
const totalExpensesEl = document.getElementById("total-expenses");
const availableBalanceEl = document.getElementById("available-balance");

const entriesListEl = document.getElementById("entries-list");
const emptyStateEl = document.getElementById("empty-state");
const clearAllBtn = document.getElementById("clear-all");
const filterButtons = document.querySelectorAll(".filter-btn");

const userSelect = document.getElementById("user-select");
const addUserBtn = document.getElementById("add-user-btn");

let appState = {
  currentUser: "Me",
  users: {
    Me: [],
  },
};

let activeFilter = "all";

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return;
    }
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && parsed.users) {
      appState = {
        currentUser: parsed.currentUser || "Me",
        users: parsed.users || { Me: [] },
      };
    } else if (Array.isArray(parsed)) {
      appState = {
        currentUser: "Me",
        users: { Me: parsed },
      };
    }
  } catch (e) {
    console.error("Failed to load stored state", e);
  }
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
  } catch (e) {
    console.error("Failed to save state", e);
  }
}

function getEntries() {
  const { currentUser, users } = appState;
  if (!users[currentUser]) {
    users[currentUser] = [];
  }
  return users[currentUser];
}

function setEntries(nextEntries) {
  appState.users[appState.currentUser] = nextEntries;
  saveState();
}

function formatCurrency(amount) {
  return `₹${amount.toLocaleString("en-IN")}`;
}

function computeSummary() {
  let totalIncome = 0;
  let totalExpenses = 0;

  for (const entry of getEntries()) {
    if (entry.type === "income") totalIncome += entry.amount;
    if (entry.type === "expense") totalExpenses += entry.amount;
  }

  const balance = totalIncome - totalExpenses;

  totalIncomeEl.textContent = formatCurrency(totalIncome);
  totalExpensesEl.textContent = formatCurrency(totalExpenses);
  availableBalanceEl.textContent = formatCurrency(balance);
}

function renderEntries() {
  entriesListEl.innerHTML = "";

  const filtered =
    activeFilter === "all"
      ? getEntries()
      : getEntries().filter((e) => e.type === activeFilter);

  if (filtered.length === 0) {
    emptyStateEl.style.display = "block";
  } else {
    emptyStateEl.style.display = "none";
  }

  filtered
    .slice()
    .sort((a, b) => b.createdAt - a.createdAt)
    .forEach((entry) => {
      const li = document.createElement("li");
      li.className = "entry";

      const main = document.createElement("div");
      main.className = "entry-main";

      const titleRow = document.createElement("div");
      titleRow.className = "entry-title-row";

      const pill = document.createElement("span");
      pill.className = `pill ${entry.type}`;
      pill.textContent =
        entry.type === "income"
          ? "Income"
          : "Expense";

      const category = document.createElement("span");
      category.className = "entry-category";
      category.textContent = entry.category;

      titleRow.appendChild(pill);
      titleRow.appendChild(category);

      const note = document.createElement("span");
      note.className = "entry-note";
      note.textContent = entry.note || "";

      main.appendChild(titleRow);
      if (entry.note) {
        main.appendChild(note);
      }

      const meta = document.createElement("span");
      meta.className = "entry-meta";
      const date = entry.date
        ? new Date(entry.date + "T00:00:00")
        : new Date(entry.createdAt);
      meta.textContent = date.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });

      const amount = document.createElement("span");
      amount.className = `entry-amount ${entry.type}`;
      amount.textContent = formatCurrency(entry.amount);

      const deleteBtn = document.createElement("button");
      deleteBtn.className = "delete-btn";
      deleteBtn.type = "button";
      deleteBtn.textContent = "✕";
      deleteBtn.title = "Delete entry";
      deleteBtn.addEventListener("click", () => {
        const remaining = getEntries().filter((e) => e.id !== entry.id);
        setEntries(remaining);
        computeSummary();
        renderEntries();
        showToast("Entry removed");
      });

      li.appendChild(main);
      li.appendChild(meta);
      li.appendChild(amount);
      li.appendChild(deleteBtn);

      entriesListEl.appendChild(li);
    });
}

function showToast(message) {
  let toast = document.querySelector(".toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add("visible");
  setTimeout(() => toast.classList.remove("visible"), 2000);
}

entryForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const type = typeInput.value;
  const amount = Number.parseInt(amountInput.value, 10);
  const category = categoryInput.value.trim();
  const note = noteInput.value.trim();
  const dateValue = dateInput.value;

  if (!amount || amount <= 0 || !category) {
    return;
  }

  const newEntry = {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    type,
    amount,
    category,
    note,
    date: dateValue || null,
    createdAt: Date.now(),
  };

  const updated = getEntries().concat(newEntry);
  setEntries(updated);
  computeSummary();
  renderEntries();

  entryForm.reset();
  typeInput.value = type;

  showToast("Entry saved");
});

filterButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    filterButtons.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    activeFilter = btn.dataset.filter || "all";
    renderEntries();
  });
});

clearAllBtn.addEventListener("click", () => {
  const currentEntries = getEntries();
  if (!currentEntries.length) return;
  const confirmed = window.confirm(
    "This will delete all entries for this user. Continue?"
  );
  if (!confirmed) return;
  setEntries([]);
  computeSummary();
  renderEntries();
  showToast("All entries cleared");
});

document.addEventListener("DOMContentLoaded", () => {
  if (!dateInput.value) {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const dd = String(today.getDate()).padStart(2, "0");
    dateInput.value = `${yyyy}-${mm}-${dd}`;
  }
});

function populateUserSelect() {
  userSelect.innerHTML = "";
  const userNames = Object.keys(appState.users);
  userNames.forEach((name) => {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    userSelect.appendChild(option);
  });
  if (!appState.users[appState.currentUser]) {
    appState.currentUser = userNames[0] || "Me";
  }
  userSelect.value = appState.currentUser;
}

userSelect.addEventListener("change", () => {
  const selected = userSelect.value;
  if (!selected) return;
  appState.currentUser = selected;
  saveState();
  computeSummary();
  renderEntries();
  showToast(`Switched to ${selected}`);
});

addUserBtn.addEventListener("click", () => {
  const name = window.prompt("Enter a name for the new user:") || "";
  const trimmed = name.trim();
  if (!trimmed) return;
  if (!appState.users[trimmed]) {
    appState.users[trimmed] = [];
  }
  appState.currentUser = trimmed;
  saveState();
  populateUserSelect();
  computeSummary();
  renderEntries();
  showToast(`Now tracking for ${trimmed}`);
});

loadState();
populateUserSelect();
computeSummary();
renderEntries();
